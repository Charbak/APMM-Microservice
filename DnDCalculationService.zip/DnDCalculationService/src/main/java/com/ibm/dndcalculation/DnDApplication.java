package com.ibm.dndcalculation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import com.apmm.service.Eddi2rkemserviceApplication;

@SpringBootApplication
public class DnDApplication {

	public static void main(String[] args) {
		SpringApplication.run(DnDApplication.class, args);
	}
}